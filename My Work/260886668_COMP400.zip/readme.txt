Name: Ryan Sowa
ID: 260886668
Prometheus Vision Facial Recognition Project

To run the test file, first ensure that .DS_Store is removed (rm .DS_Store) from the "training_set" and "identify" folders and then type "python test.py" in the terminal.


